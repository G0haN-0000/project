# System Rezerwacji Sprzętu Komputerowego

Aplikacja webowa do zarządzania rezerwacjami sprzętu (laptopy, rzutniki, tablety) w szkole lub firmie.

## Technologie
- Python 3 + Flask
- PostgreSQL
- Linux Ubuntu
- msmtp (powiadomienia e-mail)
- Cron (backupy)

## Uruchomienie

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```

## Backup & e-mail

- backup.sh – backup bazy danych
- powiadomienie.sh – e-mail z msmtp