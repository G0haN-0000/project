#!/bin/bash
echo -e "Subject: Nowa rezerwacja

Nowa rezerwacja została złożona." | msmtp admin@szkola.pl